import Slide from './Slide'

const Slide13 = () => {
  return (
    <Slide className="flex items-center justify-center">
      <h1 className="title">Дякую за увагу!</h1>
    </Slide>
  )
}

export default Slide13
